# Suno Song Creator GPT — Knowledge Pack

This pack consolidates the original Suno Song Creator skill/reference/template files into 7 knowledge files for a Custom GPT.

## Upload these 7 files to GPT Knowledge

1. `01_Core_Workflow.md`
2. `02_Routes_Ideation_and_Input.md`
3. `03_Music_DNA_Reference_and_Revision.md`
4. `04_Lyrics_Vocals_and_Pronunciation.md`
5. `05_Suno_Control_Prompt_Tags_and_Output.md`
6. `06_Duration_Instruments_and_Generation_Fix.md`
7. `07_Beginner_Music_Terms.md`

## Recommended GPT setup

- Put behavior rules and the final workflow in the GPT **Instructions** field.
- Put these 7 consolidated files in **Knowledge**.
- Enable **Web Search** when you want reference-song / genre / current-Suno research.
- Enable **Code Interpreter & Data Analysis** for MIDI inspection, duration calculations, and WAV conversion.

## Consolidation policy

- Original source text is preserved inside clearly labeled `SOURCE FILE` sections.
- No conflicting source rules were silently rewritten or reconciled during consolidation.
- `music-dna.json` is embedded verbatim inside a JSON code block in file 03.
- Templates remain templates; workflow/reference files remain reference material.

## Original-source mapping

### 01 Core Workflow
- SKILL(3).md
- conversation-modes.md
- skill-boundary-and-handoff.md
- knowledge-retrieval.md

### 02 Routes / Ideation / Input
- dialogue-lyrics-story-first.md
- dialogue-music-style-first.md
- five-choice-ideation.md
- song-input.md
- intent-to-suno.md

### 03 Music DNA / Reference / Revision
- music-dna-and-resolution.md
- music-dna.json
- reference-song-rules.md
- revision-impact-workflow.md
- songwriting-principles.md

### 04 Lyrics / Vocals / Pronunciation
- lyric-guidelines.md
- lyrics-field-control.md
- japanese-pronunciation.md
- rap-boundary-control.md
- vocal-plan.md
- lyrics.md

### 05 Suno Control / Prompt / Tags / Output
- suno-control-workflow.md
- suno-prompt-guidelines.md
- tag-plan.md
- suno-output.md

### 06 Duration / Instruments / Generation Fix
- duration-control.md
- instrument-plan.md
- generation-diagnosis.md
- generation-log.md

### 07 Beginner Terms
- beginner-music-terms.md
